kafka-topics.bat --create --topic OrderPlaced --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
kafka-topics.bat --create --topic InventoryUpdated --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1
kafka-topics.bat --create --topic PaymentMade --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

kafka-topics.bat --list --bootstrap-server localhost:9092